tiene(juan,auto(rojo,corvette)).
tiene(juan,gato(negro,angora,silvestre)).
tiene(elvis,copyright(song,'jailhouse look')).
tiene(tolstoy,copyright(book,'war and peace')).
tiene(elvis,auto(rojo,cadillac)).
