persona(name(juan,codi),f,date(2,2,1900)).
