tiene(juan,poema).
tiene(maria,poema).
tiene(juan,la_saeta).
tiene(juan,poema(la_saeta,machado)).
tiene(juan,poema(la_saeta,autor(antonio,machado))).
tiene(maria, poema(la_encina,autor(manuel,machado))).
